package com.capegemini.BVS.service;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

import com.capegemini.BVS.dto.LoginDto;
import com.capegemini.BVS.exe.BackgroundVerificationController;
import com.capgemini.BVS.dao.FileDao;

public class LoginService {
//	public void ed() {
//		File logfile = new File("C:\\Users\\user\\Documents\\workspace-sts-3.9.9.RELEASE\\Rahul Kumar\\BackgroundVerificationSystem\\src\\main\\resources\\login.txt");
//		FileOutputStream fos=null;
//		HashMap<Integer, LoginDto> hash = new HashMap<Integer, LoginDto>();
//		LoginDto log1 = new LoginDto(1,"rahul@123");
//		LoginDto log2 = new LoginDto(2,"kapil@123");
//		LoginDto log3 = new LoginDto(3,"rtvik@123");
//		LoginDto log4 = new LoginDto(4,"prince@123");
//		hash.put(log1.getEmpId(), log1);
//		hash.put(log2.getEmpId(), log2);
//		hash.put(log3.getEmpId(), log3);
//		hash.put(log4.getEmpId(), log4);
//		try {
//			fos = new FileOutputStream(logfile); 
//            ObjectOutputStream out = new ObjectOutputStream(fos); 
//              
//            // Method for serialization of object 
//            out.writeObject(hash); 
//              
//            out.close(); 
//            fos.close(); 
//		}catch(Exception e) {
//			e.printStackTrace();
//		}
//		System.out.println("Done");
//	}
		
	public void login(LoginDto login) {
		System.out.println("------------------------------------------------------------------------------------------");
		Scanner scn = new Scanner(System.in);
		HashMap<Integer, LoginDto> object1=null;
		int valid =0;
		try {
			
			ObjectInputStream in = new FileDao().getLoginData();
			
			object1 = (HashMap<Integer, LoginDto>)in.readObject();
			
			for (Map.Entry mapElement : object1.entrySet()) {
				LoginDto log = (LoginDto)mapElement.getValue();
				if(log.getEmpId()==login.getEmpId() && (log.getPassword().equals(login.getPassword())) ) {
					//valid =log.getRoleId();
					if(log.getEmpId()==1) {
						System.out.println("Logged in as Admin");
						valid=1;
						BcgService bcg = new BcgService();
						System.out.println();
						System.out.println("List of employee who have uploaded the document :");
						bcg.getByName();
						System.out.println("Enter the id you want verify the document");
						int id = scn.nextInt();
						bcg.getDocument(id);
						break;
					}
					else
					{
						System.out.println("Logged in as Employee");
						valid=1;
						System.out.print("What you want to do: \n1.status\n2.store\n ");
						int choice = scn.nextInt();
						if(choice==1) {
							new EmployeeService().viewStatus(log.getEmpId());
						}
						else {
							new EmployeeService().storeDocument(login);
						}
						break;
					}
					
				}
			}		
			
			if(valid==0) {
				System.out.println("Wrong EmplyeeId or Password or Role Id");
				new BackgroundVerificationController().logging();
			}
			
			in.close();
			
		}catch(Exception e) {
			e.printStackTrace();
		}
			
	}
}
