package com.capegemini.BVS.exe;

import java.io.File;
import java.io.FileOutputStream;
import java.io.ObjectOutputStream;
import java.util.HashMap;
import java.util.Scanner;

import com.capegemini.BVS.dto.EmployeeDocumentDto;
import com.capegemini.BVS.dto.LoginDto;
import com.capegemini.BVS.service.LoginService;
import com.capegemini.BVS.service.ResetPassword;

public class BackgroundVerificationController {
	Scanner scn = new Scanner(System.in);
	public static void main(String[] args) {
		System.out.println("------------------------------------------------------------------------------------------");
		System.out.println("                      Background Verification System                                      ");
		System.out.println("------------------------------------------------------------------------------------------");
		new BackgroundVerificationController().logging();
		//new LoginService().ed();
//		File logfile = new File("C:\\Users\\user\\Documents\\workspace-sts-3.9.9.RELEASE\\Rahul Kumar\\BackgroundVerificationSystem\\src\\main\\resources\\doc.txt");
//		FileOutputStream fos=null;
//		HashMap<Integer, EmployeeDocumentDto> hash = new HashMap<Integer, EmployeeDocumentDto>();
//		
//		try {
//			fos = new FileOutputStream(logfile); 
//            ObjectOutputStream out = new ObjectOutputStream(fos); 
//              
//            // Method for serialization of object 
//            out.writeObject(hash); 
//              
//            out.close(); 
//            fos.close(); 
//		}catch(Exception e) {
//			e.printStackTrace();
//		}
//		System.out.println("Done");
////
		
		
	}
	
	public void logging() {
			int x= 0;
			
			System.out.println("1. Login ");
			System.out.println("2. Forget Password");
			System.out.println("3. Exit");
			x = scn.nextInt();
			if(x==1) {
				System.out.println("Enter the EmpId");
				int empId = scn.nextInt();
				System.out.println("Enter the Password");
				String password = scn.next();
//				System.out.println("Enter the RoleId \n1. Admin\n2. Employee");
//				int roleId = scn.nextInt();
				LoginDto ldto = new LoginDto(empId, password);
				LoginService log = new LoginService();
				log.login(ldto);
			}
			else if(x==2){
				new ResetPassword().resetPassword();
			}
			else {
				//System.out.println("Enter valid Choice");
				System.exit(0);
			}
	}
}
