package com.capgemini.BVS.dao;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;


public class FileDao {
	public ObjectInputStream getLoginData() {
		File logfile = new File("C:\\Users\\user\\Documents\\workspace-sts-3.9.9.RELEASE\\Rahul Kumar\\BackgroundVerificationSystem\\src\\main\\resources\\login.txt");
		FileInputStream fis=null;
		ObjectInputStream in= null;
		try {
			fis = new FileInputStream(logfile);
			
			in = new ObjectInputStream(fis);
	
		}catch(Exception e) {
			e.printStackTrace();
		}
		return in;
	}
	
	public ObjectOutputStream setLoginData() {
		File logfile = new File("C:\\Users\\user\\Documents\\workspace-sts-3.9.9.RELEASE\\Rahul Kumar\\BackgroundVerificationSystem\\src\\main\\resources\\login.txt");
		FileOutputStream fos=null;
		ObjectOutputStream out =null;
		try {
			fos = new FileOutputStream(logfile);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return out;
	}
	
	
	public void getDocData() {
		
	}
}
